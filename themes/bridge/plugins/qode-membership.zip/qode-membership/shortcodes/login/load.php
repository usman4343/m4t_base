<?php
include_once QODE_MEMBERSHIP_SHORTCODES_PATH.'/login/functions.php';
include_once QODE_MEMBERSHIP_SHORTCODES_PATH.'/login/login.php';