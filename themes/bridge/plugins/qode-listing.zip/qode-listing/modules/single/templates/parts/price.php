<?php
echo $article_obj->getPriceHtml();