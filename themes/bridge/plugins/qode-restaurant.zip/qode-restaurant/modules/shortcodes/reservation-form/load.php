<?php

include_once QODE_RESTAURANT_SHORTCODES_PATH.'/reservation-form/functions.php';
include_once QODE_RESTAURANT_SHORTCODES_PATH.'/reservation-form/reservation-form.php';