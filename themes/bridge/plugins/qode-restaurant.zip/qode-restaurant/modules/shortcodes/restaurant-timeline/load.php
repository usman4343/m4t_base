<?php

include_once QODE_RESTAURANT_SHORTCODES_PATH . '/restaurant-timeline/functions.php';
include_once QODE_RESTAURANT_SHORTCODES_PATH . '/restaurant-timeline/restaurant-timeline.php';
