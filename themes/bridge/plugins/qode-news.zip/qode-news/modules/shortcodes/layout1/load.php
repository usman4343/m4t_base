<?php

include_once QODE_NEWS_SHORTCODES_PATH.'/layout1/functions.php';
include_once QODE_NEWS_SHORTCODES_PATH.'/layout1/layout1.php';